<?php

namespace Database\Factories;

use App\Models\Pregunta;
use Illuminate\Database\Eloquent\Factories\Factory;

class PreguntaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Pregunta::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $curso = random_int(2010, 2020);
        $curso = $curso . "/" . $curso + 1;

        return [
            'nombre' => $this->faker->text(25),
            'contenido' => $this->faker->text(150),
            'respuesta' => $this->faker->randomElement(['a', 'b', 'c', 'd']),
            'nombre_profesor' => $this->faker->name,
            'curso' => $curso,
            'nombre_examen' => $this->faker->randomElement(['Examen_1', 'Examen_2', 'Examen_3', 'Examen_4', 'Examen_5']),
            'ciclo' => $this->faker->randomElement(['Desarrollo Web', 'Desarrollo de Aplicaciones Multiplataforma']),
            'materia' => $this->faker->randomElement(['DSW', 'BAE', 'ETS', 'PRO', 'AIF', 'ITG', 'DEW', 'FOL', 'EMR']),
            'estado' => $this->faker->randomElement(['Activa', 'Oculta', 'Opcional', 'Borrador']),
        ];
    }
}
