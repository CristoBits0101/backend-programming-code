//Productos
function cargarComboListaCategorias() {

}

function cargarAnadirProductos() {

}

function cargarProductos(cod) {

}

function crear_fila(campos, tipo) {

}

function crearFormulario(texto, cod, funcion) {

}

function crearTablaProductos(productos, codCat) {

}

function eliminarProducto(codProd, codCat) {

}

function anadirProducto(formulario) {
}

//Carrito
function anadirProductos(formulario) {

}

function eliminarProductos(formulario) {

}

function cargarCarrito() {

}

function crearTablaCarrito(productos) {

}

function procesarPedido() {

}

//Categorias
function cargarAnadirCategorias() {

}

function cargarEditarCategoria(codCat) {

}

function cargarCategorias() {

}

function crearTablaCategorias(categorias) {

}

function anadirCategoria(formulario) {

}

function eliminarCategoria(codCat) {

}

function editarCategoria(formulario) {

}