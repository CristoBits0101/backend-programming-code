<?php
//Configuración y Usuarios
function leerXmlConfiguracion($nombre, $esquema) {

}

function conectarBD() {

}

function comprobar_usuario($nombre, $clave) {

}

//Pedidos
function insertar_pedido($carrito, $codRes) {

}

//Categorías
function anadir_categoria($nombre, $descripcion) {

}

function editar_categoria($codCat, $nombre, $descripcion) {

}

function eliminar_categoria($codCategoria) {

}

function cargar_categorias() {

}

function cargar_categoria($codCat) {

}

function cargar_productos_categoria($codCat) {

}

//Productos
function cargar_productos($codigosProductos) {

}

function anadir_producto($nombre, $descripcion, $peso, $stock, $categoria) {

}

function eliminar_producto($codProducto) {

}