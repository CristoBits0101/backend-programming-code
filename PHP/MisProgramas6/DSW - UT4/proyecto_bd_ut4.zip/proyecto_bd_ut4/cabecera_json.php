<header>
    <span id="cab_usuario"></span>
    <a href="#" onclick="cargarAnadirCategorias();">Añadir Categorías</a>
    <a href="#" onclick="cargarCategorias();">Listar Categorías</a>
    <a href="#" onclick="cargarAnadirProductos();">Añadir Productos</a>
    <a href="#" onclick="cargarCarrito();">Carrito</a>
    <a href="#" onclick="cerrarSesion();">Cerrar sesión</a>
</header>
<hr>