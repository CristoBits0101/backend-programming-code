<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar Pokemon</title>
</head>
<body>
    <form action="" method="">
    <label for="">Nombre:</label>
        <input type="text" name="nombre" id="">
        <label for="">Altura:</label>
        <input type="text" name="altura" id="">
        <label for="">Peso:</label>
        <input type="text" name="peso" id="">
        <label for="">Tipo:</label>
        <select name="tipo" id="tipo">
        </select>
        <button type="submit">Insertar</button>

    </form>
    
</body>
</html>