<?php

    require "./modulo.php";

    class FranjaHorario extends Modulo
    {
        private $dia;
        private $hora;
        private $color;

        function __construct
        (
            $Curso,
            $Clase,
            $Materia,
            $dia,
            $hora,
            $color,
        ) 
        {
            $this->Curso   = $Curso;
            $this->Clase   = $Clase;
            $this->Materia = $Materia;
            $this->dia     = $dia;
            $this->hora    = $hora;
            $this->color   = $color;
        }

        /**
         * Get the value of dia
         */ 
        public function getDia()
        {
                return $this->dia;
        }

        /**
         * Set the value of dia
         *
         * @return  self
         */ 
        public function setDia($dia)
        {
                $this->dia = $dia;

                return $this;
        }

        /**
         * Get the value of hora
         */ 
        public function getHora()
        {
                return $this->hora;
        }

        /**
         * Set the value of hora
         *
         * @return  self
         */ 
        public function setHora($hora)
        {
                $this->hora = $hora;

                return $this;
        }

        /**
         * Get the value of color
         */ 
        public function getColor()
        {
                return $this->color;
        }

        /**
         * Set the value of color
         *
         * @return  self
         */ 
        public function setColor($color)
        {
                $this->color = $color;

                return $this;
        }
    }
    
?>