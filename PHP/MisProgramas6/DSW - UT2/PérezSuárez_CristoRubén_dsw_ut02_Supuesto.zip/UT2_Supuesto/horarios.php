<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>Horario Docente</title>
</head>

<body>
    <div class="container">
        <h1 class="text-center">Horario de Clases</h1>

        <div class="container col-md-8">
        </div>
        <br>
        <br>

        <h2>Operaciones Horario:</h2>

        <form action="./validaciones.php" method="post" enctype="multipart/form-data">
            <div class="col-md-12 row g-3">
                <div class="col-4">
                    <label>Curso:</label>
                    <select class="form-select" id="curso" name="curso">
                        <option value='Español'></option>
                        <option value='Inglés'></option>
                    </select>
                </div>
                <div class="col-4">
                    <label>Día:</label>
                    <select class="form-select" id="dia" name="dia">
                        <option value='Lunes'></option>
                        <option value='Martes'></option>
                    </select>
                </div>
                <div class="col-4">
                    <label>Hora:</label>
                    <select class="form-select" id="hora" name="hora">
                        <option value='11:00'></option>
                        <option value='12:00'></option>
                    </select>
                </div>
            </div>
            <div class="col-md-12 row g-3">
                <div class="col-4">
                    <label>Materia:</label>
                    <select class="form-select" id="materia" name="materia">
                        <option value='Sintaxis'></option>
                        <option value='Regulaciones'></option>
                    </select>
                </div>
                <div class="col-4">
                    <label>Clase:</label>
                    <select class="form-select" id="clase" name="clase">
                        <option value='1A'></option>
                        <option value='1B'></option>
                    </select><br>
                </div>
                <div class="col-4">
                    <label>Color:</label>
                    <select class="form-select" id="color" name="color">
                        <option value='Rojo'></option>
                        <option value='Verde'></option>
                    </select>
                </div>
            </div>
            <br>
            <br>
            <div class="col-md-12 row g-3">
                <div class="col-4">
                    <input type="submit" class="btn btn-primary" value="Insertar Hora">
                    <input type="submit" class="btn btn-danger" value="Eliminar Hora">
                </div>

                <div class="col-6">
                    <input type="file" id="fhorario">
                    <input type="submit" class="btn btn-info" value="Cargar Horario">
                </div>
            </div>

        </form>
    </div>
</body>

</html>