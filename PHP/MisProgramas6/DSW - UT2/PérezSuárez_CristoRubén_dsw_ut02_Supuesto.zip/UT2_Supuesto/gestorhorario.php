<?php

    function insertarHora($FranjaHorario) // contiene la información almacenada de todos los campos
    {

        $carpetaHorarios = '/UT2_Supuesto/horarios';

        if 
        (
            !file_exists($carpetaHorarios)
        ) 
        {
            mkdir($carpetaHorarios, 0777, true);
        }

        $_file = fopen("./horarios/horarios.dat", "w");

        fwrite($_file, $FranjaHorario);

        fclose($_file);

        echo '¡Fichero actualizado! ✅<br/><br/>';
    }

?>