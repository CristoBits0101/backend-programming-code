<?php

    class Modulo
    {
        private $Curso;
        private $Clase;
        private $Materia;

        /**
         * Get the value of Curso
         */ 
        public function getCurso()
        {
                return $this->Curso;
        }

        /**
         * Set the value of Curso
         *
         * @return  self
         */ 
        public function setCurso($Curso)
        {
                $this->Curso = $Curso;

                return $this;
        }

        /**
         * Get the value of Clase
         */ 
        public function getClase()
        {
                return $this->Clase;
        }

        /**
         * Set the value of Clase
         *
         * @return  self
         */ 
        public function setClase($Clase)
        {
                $this->Clase = $Clase;

                return $this;
        }

        /**
         * Get the value of Materia
         */ 
        public function getMateria()
        {
                return $this->Materia;
        }

        /**
         * Set the value of Materia
         *
         * @return  self
         */ 
        public function setMateria($Materia)
        {
                $this->Materia = $Materia;

                return $this;
        }
    }
    
?>