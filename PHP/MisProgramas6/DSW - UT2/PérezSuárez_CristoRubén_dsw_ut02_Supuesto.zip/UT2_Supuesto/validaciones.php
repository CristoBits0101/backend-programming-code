<?php

    require "./franjahorario.php";
    require "./gestorhorario.php";

    if
    (
        $_REQUEST['curso'] !== 'Español'        && 
        $_REQUEST['curso'] !== 'Inglés'         ||

        $_REQUEST['dia']   !== 'Lunes'          && 
        $_REQUEST['dia']   !== 'Martes'         ||

        $_REQUEST['hora']  !== '11:00'          && 
        $_REQUEST['hora']  !== '12:00'          ||

        $_REQUEST['materia'] !== 'Sintaxis'     && 
        $_REQUEST['materia'] !== 'Regulaciones' ||

        $_REQUEST['clase'] !== '1A'             && 
        $_REQUEST['clase'] !== '1B'             ||

        $_REQUEST['color'] !== 'Rojo'           && 
        $_REQUEST['color'] !== 'Verde'   
    )
    {
        throw new Exception("¡ERROR! (verifique las opciones seleccionadas).");
    }

    $_FranjaHorario = new FranjaHorario
    (
        $_REQUEST['curso'],
        $_REQUEST['dia'],
        $_REQUEST['hora'],
        $_REQUEST['materia'],
        $_REQUEST['clase'],
        $_REQUEST['color']
    );

    $FH = $_FranjaHorario->getCurso()   . ';' . 
          $_FranjaHorario->getDia()     . ';' . 
          $_FranjaHorario->getHora()    . ';' . 
          $_FranjaHorario->getMateria() . ';' . 
          $_FranjaHorario->getClase()   . ';' .
          $_FranjaHorario->getColor()   . '@' ;

    insertarHora($FH);

?>