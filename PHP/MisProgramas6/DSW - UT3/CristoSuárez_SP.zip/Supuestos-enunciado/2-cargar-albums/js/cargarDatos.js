function cargarAlbums() 
{
    fetch('../datos/bd.php')

        .then(response => 
        {
            if (response.ok) 
            {
                return response.json()
            }
            else 
            {
                throw ('Error en la petición realizada.')
            }
        })

        .then(json => 
        {
            // Tabla 1.
            // document.getElementById("contenido").innerHTML = `
            //     <table>
            //         <thead>
            //             <tr>
            //                 <th>Tienda</th>
            //                 <th>Precio</th>
            //             </tr>
            //         </thead>
            //         <tbody>
            //             <tr>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>
            //                     <img 
            //                         src="${json[0]['imagen']}" 
            //                         alt="Error loading image..."
            //                         with="25px" height="75px"
            //                     >
            //                 </td>
            //             </tr>
            //         </tbody>
            //     </table>
            // `

            // Tabla 2.
            // document.getElementById("contenido").innerHTML = `
            //     <table>
            //         <thead>
            //             <tr>
            //                 <th>Tienda</th>
            //                 <th>Precio</th>
            //             </tr>
            //         </thead>
            //         <tbody>
            //             <tr>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>${json[0]['']}</td>
            //                 <td>
            //                     <img 
            //                         src="${json[0]['imagen']}" 
            //                         alt="Error loading image..."
            //                         with="25px" height="75px"
            //                     >
            //                 </td>
            //             </tr>
            //         </tbody>
            //     </table>
            // `
        })
            
}