<?php

    require "../clases/album.php";

    $album = new Album();

    function obtenerCanciones()                                 
    {
        $albums    = simplexml_load_file("./albums.xml");        

        $canciones = $albums->xpath("///cancion");
        
        $album->setCancion($canciones);                           
    }

    function obtenerTiendas()                                   
    {
        $albums  = simplexml_load_file("./albums.xml");        

        $tiendas = $albums->xpath("///tienda");
        
        $album->setTiendas($canciones);
    }

?>