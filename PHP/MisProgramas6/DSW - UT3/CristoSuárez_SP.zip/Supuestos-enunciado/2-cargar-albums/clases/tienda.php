<?php

    require "./album.php";

    class Tienda extends Album
    {
        private $tienda;

        function __construct($datos)
        {

        }

        /**
         * Get the value of tienda
         */ 
        public function getTienda()
        {
                return $this->tienda;
        }

        /**
         * Set the value of tienda
         *
         * @return  self
         */ 
        public function setTienda($tienda)
        {
                $this->tienda = $tienda;

                return $this;
        }
    }
?>