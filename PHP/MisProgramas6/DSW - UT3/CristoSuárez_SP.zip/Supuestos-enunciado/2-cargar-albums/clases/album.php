<?php

    require "../datos/bd.php";

    class Album
    {
        private $tiendas;
        private $canciones;

        function __construct($datos)
        {

        }

        /**
         * Get the value of tiendas
         */ 
        public function getTiendas($datos)
        {
            return $this->tiendas;
        }

        /**
         * Set the value of tiendas
         *
         * @return  self
         */ 
        public function setTiendas()
        {
            $this->tiendas = obtenerTiendas($datos);

            return $this;
        }

        /**
         * Get the value of canciones
         */ 
        public function getCanciones()
        {
            return $this->canciones;
        }

        /**
         * Set the value of canciones
         *
         * @return  self
         */ 
        public function setCanciones()
        {
            $this->canciones = obtenerCanciones();

            return $this;
        }
    }
?>