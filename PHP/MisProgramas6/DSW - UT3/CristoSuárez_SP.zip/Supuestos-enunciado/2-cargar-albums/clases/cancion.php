<?php

    require "./album.php";

    class Cancion extends Album
    {
        private $cancion;

        function __construct($datos)
        {

        }

        /**
         * Get the value of cancion
         */ 
        public function getCancion()
        {
            return $this->cancion;
        }

        /**
         * Set the value of cancion
         *
         * @return  self
         */ 
        public function setCancion($cancion)
        {
            $this->cancion = $cancion;

            return $this;
        }
    }
?>