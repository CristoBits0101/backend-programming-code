<?php

    $nombre = $_POST['usuario'];
    $clave  = $_POST['clave'];

    print_r($nombre);
    print_r($clave);

    function comprobar_usuario($nombre, $clave)                 // Comprobar usuarios registrados.
    {
        $usuarios = simplexml_load_file("./configuracion.xml"); // Carga la configuración del XML.

        $usuarioEmail    = $usuarios->xpath("///alias");
        $usuarioPassword = $usuarios->xpath("///clave");
        
        if 
        (
            $usuarioEmail[0]    == $nombre &&                   // Se comprueba las coincidencias de datos.
            $usuarioPassword[0] == $clave
        ) 
        {
            echo json_encode(true);                             // Retornamos, se ha encontrado coincidencias.
        }                                              

        echo json_encode(false);                                // Retornamos, no se ha encontrado coincidencias.
    }

?>