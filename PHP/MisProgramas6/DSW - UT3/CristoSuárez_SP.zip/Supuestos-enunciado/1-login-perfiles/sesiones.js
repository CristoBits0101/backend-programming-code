const login = () =>
{
    let usuario = document.getElementById('usuario')
    let clave   = document.getElementById('clave')

    let data = new FormData()

    data.append('usuario', usuario)
    data.append('clave', clave)

    fetch('bd.php', {method: 'POST', body: data})

        .then(response => 
        {
            if (response.ok) 
            {
                return response.json()
            }
            else 
            {
                throw ('Error en la petición realizada.')
            }
        })

        .then(json => 
        {
            if (json == true) 
            {
                // Serialización
            }
            else 
            {
                throw ('Error en la petición realizada')
            } 
            // // Serialización de matriz indexada + asociativa.
            // document.getElementById("contenido").innerHTML = `
            //     <table>
            //         <thead>
            //             <tr>
            //                 <th>ISBN</th>
            //                 <th>Título</th>
            //                 <th>Escritores</th>
            //                 <th>Género</th>
            //                 <th>Páginas</th>
            //                 <th>Imagén</th>
            //             </tr>
            //         </thead>
            //         <tbody>
            //             <tr>
            //                 <td>${json[0]['isbn']}</td>
            //                 <td>${json[0]['titulo']}</td>
            //                 <td>${json[0]['escritores']}</td>
            //                 <td>${json[0]['genero']}</td>
            //                 <td>${json[0]['numpaginas']}</td>
            //                 <td>
            //                     <img 
            //                         src="${json[0]['imagen']}" 
            //                         alt="Error loading image..."
            //                         with="25px" height="75px"
            //                     >
            //                 </td>
            //                 <td>
            //                     <input type="number" id="valor5">
            //                     <button
            //                         type="button" 
            //                         onclick="anadirLibros(${funcion = 1}, ${json[0]['isbn']})"
            //                     >
            //                             Añadir
            //                     </button>
            //                 </td>
            //             </tr>
            //         </tbody>
            //     </table>
            // `           
        })
}