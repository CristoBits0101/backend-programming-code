<?php
    
    require_once "./bd.php";

    echo json_encode(cargar_libros());

?>