<?php

    function validar_estado_sesion()
    {
        // Activamos la llamada a la variable global sesión para poder hacer uso de su estado en el archivo.
        session_start();

        // Se comprueba si la clave usuario no está declarada y si no es diferente de null.
        if (!isset($_SESSION['usuario']))
        {
            // Le invitamos a iniciar sesión para poder usar el carrito.
            header("Location: login.php?redirigido=true");
        }
    }

?>