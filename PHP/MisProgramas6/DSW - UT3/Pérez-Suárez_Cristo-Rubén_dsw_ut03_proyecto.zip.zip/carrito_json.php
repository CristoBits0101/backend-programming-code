<?php
    
    require_once "./bd.php";
    require "./sesiones.php";

    validar_estado_sesion();

    $datosCarrito = Array();

    array_push($datosCarrito, $_SESSION['cantidad']  );
    array_push($datosCarrito, $_SESSION['isbn']      );
    array_push($datosCarrito, $_SESSION['titulo']    );
    array_push($datosCarrito, $_SESSION['escritores']);
    array_push($datosCarrito, $_SESSION['genero']    );
    array_push($datosCarrito, $_SESSION['numpaginas']);
    array_push($datosCarrito, $_SESSION['imagen']    );

    echo json_encode($datosCarrito);

?>