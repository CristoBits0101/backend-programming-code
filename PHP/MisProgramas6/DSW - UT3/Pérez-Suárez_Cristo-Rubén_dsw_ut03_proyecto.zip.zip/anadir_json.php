<?php
    
    require_once "./bd.php";
    require "./sesiones.php";

    // Comprobamos si el libro existe en la base de datos y enviamos la respuesta.
    if (isset($_POST['numero']) && !empty($_POST['numero']))
    {
        list(
                $boolean, 
                $isbn, 
                $titulo, 
                $escritores, 
                $genero,
                $numpaginas,
                $imagen,
            ) = cargar_libros_carrito($_POST['numero']);
        
            $datosLibro = Array();

            array_push($datosLibro, $boolean);
            array_push($datosLibro, $isbn);
            array_push($datosLibro, $titulo);
            array_push($datosLibro, $escritores);
            array_push($datosLibro, $genero);
            array_push($datosLibro, $numpaginas);
            array_push($datosLibro, $imagen);
            array_push($datosLibro, $_POST['cantidad']);

            echo json_encode($datosLibro);
    }

    else 
    {
        throw new Exception('¡Error!, El número de isbn no es válido.');
    }

?>