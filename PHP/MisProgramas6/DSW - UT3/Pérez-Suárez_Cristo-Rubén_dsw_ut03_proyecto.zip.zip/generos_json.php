<?php

    require "./bd.php";

    echo json_encode(cargar_generos());

?>