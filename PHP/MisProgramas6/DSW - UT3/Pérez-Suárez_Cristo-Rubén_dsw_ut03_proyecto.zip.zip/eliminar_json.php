<?php
    
    require_once "./bd.php";

?>