<?php
    
    require_once 'sesiones.php';

    validar_estado_sesion();        // Comprobamos si la sesión está iniciada antes de destruirla.

    session_destroy();              // Destruimos la sesión.

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

</head>

<body>

    <p>La sesión se cerró correctamente, hasta la próxima</p>

    <a href="login.php">Ir a la página de login</a>

</body>

</html>