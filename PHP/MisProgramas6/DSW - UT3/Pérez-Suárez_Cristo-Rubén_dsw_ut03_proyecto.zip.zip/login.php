<!-- P H P -->
<?php

    require_once "./bd.php";
    
    // Lo óptimo hubiera sido disparar un error con JS y pintarlo dentro del input o añadir al input un texto interior con un placeholder mediante una cadena.
    try
    {
        if ($_SERVER["REQUEST_METHOD"] === "POST")
        {
            $buscarXML = comprobar_usuario($_POST['usuario'], $_POST['clave']);
            
            if ($buscarXML === false) 
            {
                echo    "<script> 
                            alert('No se ha podido encontrar tu cuenta.'); 
                        </script>";
            }

            else 
            {
                session_start();

                $_SESSION['usuario'] = $_POST['usuario'];

                header("Location: principal.php");
            }
        }
    }
    
    catch (Exception $e) 
    {
        echo '<p style="color:red">Excepción: ' . $e->getMessage() . "</p><br>";
    }

?>

<!-- H T M L -->
<!DOCTYPE html>

<html>

<head>

    <title>Formulario de login</title>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- C S S -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

    <div class="container-fluid">
        <div class="col-md-4 order-md-1">

            <h4>Librería</h4>

            <section id="login">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

                    <div class="form-group">
                        
                        <label for="usuario">Usuario</label>
                        <input 
                            class="form-control" 
                            id="usuario" 
                            name="usuario" 
                            type="text"
                        >

                        <label for="clave">Clave</label>
                        <input 
                            class="form-control" 
                            id="clave" 
                            name="clave" 
                            type="password"
                        >

                    </div>

                    <input class="btn btn-primary btn-lg" value="Iniciar Sesión" type="submit">

                </form>
            </section>

        </div>
    </div>

</body>

</html>