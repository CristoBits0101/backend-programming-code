<?php
    
    require_once "./bd.php";

    if (isset($_REQUEST['genero']) && !empty($_REQUEST['genero']))
    {
        echo json_encode(cargar_libros_generos($_REQUEST['genero']));
    }
    else 
    {
        throw new Exception();
    }

?>