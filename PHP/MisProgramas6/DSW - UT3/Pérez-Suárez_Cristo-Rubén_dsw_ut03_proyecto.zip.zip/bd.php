<?php
    
    function comprobar_usuario($nombre, $clave)                 // Comprobar usuarios registrados.
    {
        $usuarios = simplexml_load_file("./configuracion.xml"); // Carga la configuración del XML.

        $usuarioEmail    = $usuarios->xpath("//usuario");
        $usuarioPassword = $usuarios->xpath("//clave");
        
        if 
        (
            $usuarioEmail[0]    == $nombre &&                   // Se comprueba las coincidencias de datos.
            $usuarioPassword[0] == $clave
        ) 
        {
            return true;                                        // Retornamos, se ha encontrado coincidencias.
        }                                              

        return false;                                           // Retornamos, no se ha encontrado coincidencias.
    }

    function cargar_generos()
    {
        $generos = simplexml_load_file("./libros.xml");         // Carga la configuración del XML.

        $arrayIndexadosGeneros = $generos->xpath("///genero");  // Almacena los generos en un array indexado.
        
        return $arrayIndexadosGeneros;                          // Retorna los géneros encontrados.
    }
    
    function cargar_libros_generos($genero)
    {
        $libros = simplexml_load_file("./libros.xml");          // Carga la configuración del XML.

        $generoLibro = Array();                                 // Guarda los libros con el mismo género.

        for ($i = 0; $i < count($libros->libro); $i++) 
        { 
            if ($libros->libro[$i]->genero == $genero)          // Busca coincidencias de género.
            {
                array_push($generoLibro, $libros->libro[$i]);   // Añade libros que tengan el género solicitado.
            }
        }

        return $generoLibro;                                    // Retornamos los libros por genero.
    }
    
    function cargar_libros()
    {
        $librosXML = simplexml_load_file("./libros.xml");

        return $librosXML->xpath("//libro");                    // Retorna todos los libros almacenados.
    }
    
    function cargar_libros_carrito($isbn)
    {
        $libros = simplexml_load_file("./libros.xml");          // Carga la configuración del XML.

        for ($i = 0; $i < count($libros->libro); $i++)          // Recorremos todos los libros de la BD.
        { 
            if ($libros->libro[$i]->isbn == $isbn)              // Busca coincidencias de código.
            {
                return                                          // Retornamos la coincidencia.                                    
                [
                    true,
                    $libros->libro[$i]->isbn,
                    $libros->libro[$i]->titulo,
                    $libros->libro[$i]->escritores,
                    $libros->libro[$i]->genero,
                    $libros->libro[$i]->numpaginas,
                    $libros->libro[$i]->imagen                    
                ];     
            }
        }
        return false;
    }
    
?>