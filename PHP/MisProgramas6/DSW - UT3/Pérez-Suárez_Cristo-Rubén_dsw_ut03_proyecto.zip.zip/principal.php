<!-- P H P -->
<?php

    
    require 'sesiones.php';     // Comprueba que el usuario haya abierto sesión o redirige.
    require_once 'bd.php';      // Comprueba que el usuario haya este registrado en la base de datos.

    validar_estado_sesion();    // Comprobamos el estado del usuario en la variable global de la sesión.

?>

<!-- H T M L -->
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Proyecto Librería</title>

    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
    <div class="container-fluid">
        <div class="col-md-12 order-md-1">

            <?php require 'cabecera.php'; ?>
    
            <h4 id="titulo">Librería</h4>

            <section id="principal">

                <h2 id=""></h2>

                <section id="contenido"></section>

                <hr>

                <a href="procesar_pedido.php" id="procesar"></a>

            </section>

            <script src="./cargarDatos.js"></script>

        </div>
    </div>
    
</body>

</html>