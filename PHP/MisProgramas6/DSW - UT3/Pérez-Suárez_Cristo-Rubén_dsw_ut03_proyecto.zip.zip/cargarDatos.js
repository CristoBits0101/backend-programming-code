// 1. Declaramos una función flecha que recibe 0 parámetros y se guarda en una constante.
const cargarGeneros = () =>
{
    // 2. Realizamos una petición de datos directamente al archivo PHP porque está al mismo nivel.
    fetch('generos_json.php')
        
        // 3. Si nos llega una respuesta del servidor la comprobamos.
        .then(response => 
        {
            // 4. Si la respuesta es válida la parseamos y la retornamos al siguiente then.
            if (response.ok) 
            {
                return response.json()
            }
            else 
            {
                throw ('Error en la petición realizada a generos_json.php')
            }
        })

        // 5. Pasamos el retorno anterior como parámetro para poder recorrerlo y serializarlo.
        .then(json => 
        {
            // ul
            let ul = document.createElement("ul")

            // for (Array[i]) {}
            for (let index = 0; index < json.length; index++) 
            {
                // li
                let li = document.createElement("li")

                // li <- genero
                li.innerHTML = `<a href="#" onclick="cargarGeneroLibros('${json[index][0]}');">${json[index][0]}</a>`

                // ul <- li
                ul.appendChild(li)
            }

            // sectionId
            let zonaInyeccion = document.getElementById("contenido")

            // section <- ""
            zonaInyeccion.innerHTML = ""

            // section <- ul, li
            zonaInyeccion.appendChild(ul)
        })
}

// Listado de Generos/Géneros de Libros.
const cargarGeneroLibros = (genero) =>
{
    let data = new FormData()

    data.append('genero', genero)

    fetch('libros_generos_json.php', {method: 'POST', body: data})

        .then(response => 
        {
            if (response.ok) 
            {
                return response.json()
            }
            else 
            {
                throw ('Error en la petición realizada a libros_generos_json.php')
            }
        })

        .then(json => 
        { 
            // Serialización de matriz indexada + asociativa.
            document.getElementById("contenido").innerHTML = `
                <table>
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Título</th>
                            <th>Escritores</th>
                            <th>Género</th>
                            <th>Páginas</th>
                            <th>Imagén</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>${json[0]['isbn']}</td>
                            <td>${json[0]['titulo']}</td>
                            <td>${json[0]['escritores']}</td>
                            <td>${json[0]['genero']}</td>
                            <td>${json[0]['numpaginas']}</td>
                            <td>
                                <img 
                                    src="${json[0]['imagen']}" 
                                    alt="Error loading image..."
                                    with="25px" height="75px"
                                >
                            </td>
                            <td>
                                <input type="number" id="valor5">
                                <button
                                    type="button" 
                                    onclick="anadirLibros(${funcion = 1}, ${json[0]['isbn']})"
                                >
                                        Añadir
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            `           
        })
}

// Listado de Libros.
const cargarLibros = () =>
{
    fetch('libros_json.php')

        .then(response => 
        {
            if (response.ok) 
            {
                return response.json() 
            }
            else 
            {
                throw ('Error en la petición realizada a libros_json.php')
            }
        })

        .then(json => 
        {
            // Serialización de matriz indexada + asociativa.
            let tabla = `
                <table>
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Título</th>
                            <th>Escritores</th>
                            <th>Género</th>
                            <th>Páginas</th>
                            <th>Imagén</th>
                        </tr>
                    </thead>
                    <tbody>
                `
             
            for (let index = 0; index < json.length; index++) 
            {
                tabla +=`
                        <tr>
                            <td>${json[index]['isbn']}</td>
                            <td>${json[index]['titulo']}</td>
                            <td>${json[index]['escritores']}</td>
                            <td>${json[index]['genero']}</td>
                            <td>${json[index]['numpaginas']}</td>
                            <td>
                                <img 
                                    src="${json[index]['imagen']}" 
                                    alt="Error loading image..."
                                    with="25px" height="75px"
                                >
                            </td>`

                switch (index) 
                {
                    case 0:
                        tabla += `
                            <td>
                                <input type="number" id="valor0">
                                <button type="button" onclick="anadirLibros(${funcion = 2}, ${json[index]['isbn']})">Añadir</button>
                            </td>`
                        break;

                    case 1:
                        tabla += `
                            <td>
                                <input type="number" id="valor1">
                                <button type="button" onclick="anadirLibros(${funcion = 2}, ${json[index]['isbn']})">Añadir</button>
                            </td>`
                        break;

                    case 2:
                        tabla += `
                            <td>
                                <input type="number" id="valor2">
                                <button type="button" onclick="anadirLibros(${funcion = 2}, ${json[index]['isbn']})">Añadir</button>
                            </td>`
                        break;

                    case 3:
                        tabla += `
                            <td>
                                <input type="number" id="valor3">
                                <button type="button" onclick="anadirLibros(${funcion = 2}, ${json[index]['isbn']})">Añadir</button>
                            </td>`
                        break;

                    case 4:
                        tabla += `
                            <td>
                                <input type="number" id="valor4">
                                <button type="button" onclick="anadirLibros(${funcion = 2}, ${json[index]['isbn']})">Añadir</button>
                            </td>`
                        break;
                
                    default:
                        break;
                }

                tabla += `
                        </tr>`
            }
            
            tabla.concat(`
                    </tbody>
                </table>'
            `)

            document.getElementById("contenido").innerHTML = tabla
        })
}

// Listado de Libros/Añadir.
const anadirLibros = (funcion, isbn) =>
{
    let cantidad = 0;
    
    // 1. Obtenemos las id de los input para ver el contenido temporal almacenado.
    if (funcion == 1) 
    {
        if      (isbn === 1) {cantidad = document.getElementById("valor5").value;}
        else if (isbn === 2) {cantidad = document.getElementById("valor5").value;}
        else if (isbn === 3) {cantidad = document.getElementById("valor5").value;}
        else if (isbn === 4) {cantidad = document.getElementById("valor5").value;}
        else if (isbn === 5) {cantidad = document.getElementById("valor5").value;}
        else 
        {
            throw 'Error al verificar la cantidad de libros...'
        }
    }

    if (funcion == 2) 
    {
        if      (isbn === 1) {cantidad = document.getElementById("valor0").value;}
        else if (isbn === 2) {cantidad = document.getElementById("valor1").value;}
        else if (isbn === 3) {cantidad = document.getElementById("valor2").value;}
        else if (isbn === 4) {cantidad = document.getElementById("valor3").value;}
        else if (isbn === 5) {cantidad = document.getElementById("valor4").value;}
        else                
        {
            throw 'Error al verificar la cantidad de libros...'
        }
    }

    // 2. Si la cantidad de libros a comprar es mayor a 0 comprobamos que existe en el almacén(BD).
    let data = new FormData()
    
    data.append('numero', isbn)
    data.append('cantidad', cantidad)
    
    fetch('anadir_json.php', {method: 'POST', body: data})

        .then(response => 
            {
                if (response.ok) 
                {
                    return response.json() 
                }
                else 
                {
                    throw ('Error en la petición realizada a anadir_json.php')
                }
            })

        .then(json => 
            {   
                if (json[0] == true) 
                {
                    alert('Producto añadido con éxito.')

                    cargarCarrito(json);
                }
                else 
                {
                    throw ('No nos quedan unidades del libro que intenta comprar.')
                }
            })

    // 3. Liberamos los datos del input para que pueda volver a usarlo adicionalmente.
    // document.getElementById("valor").innerHTML = ''
}

// Listado de Libros/Eliminar.
const eliminarLibros = (isbn) =>
{  
   for (let index = 0; index < datosCarrito.length; index++) 
   {
        if (datosCarrito[index][1][0] = isbn) 
        {
            datosCarrito.splice(index,1)
            alert('Producto eliminado con éxito')
        }
   }

   if (datosCarrito.length === 0) 
   {
        document.getElementById("contenido").innerHTML = '<h2>El carrito está vacío.</h2>'
        document.getElementById("procesar").innerHTML = ''
   }

   else 
   {
        let tabla = `
                <table>
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Título</th>
                            <th>Escritores</th>
                            <th>Género</th>
                            <th>Páginas</th>
                            <th>Imagén</th>
                            <th>Unidades</th>
                        </tr>
                    </thead>
                    <tbody>
                `
                for (let index = 0; index < datosCarrito.length; index++) 
                {
                    tabla +=`
                    <tr>
                        <td>${datosCarrito[index][1][0]}</td>
                        <td>${datosCarrito[index][2][0]}</td>
                        <td>${datosCarrito[index][3][0]}</td>
                        <td>${datosCarrito[index][4][0]}</td>
                        <td>${datosCarrito[index][5][0]}</td>
                        <td>
                            <img 
                                src="${datosCarrito[index][6][0]}" 
                                alt="Error loading image..."
                                with="25px" height="75px"
                            >
                        </td>
                        <td>${datosCarrito[index][7][0]}</td>
                        <td>
                            <input type="number" id="valor0">
                            <button type="button" onclick="eliminarLibros(${datosCarrito[index][1][0]})">Eliminar</button>
                        </td>
                    </tr>`
                }
                
        tabla.concat(`
                </tbody>
            </table>
        `)
        document.getElementById("titulo").innerHTML = 'Carrito de Libros'
        document.getElementById("contenido").innerHTML = tabla
        document.getElementById("procesar").innerHTML = 'Realizar pedido'
    }
}

var datosCarrito = new Array();

// Ver carrito.
const cargarCarrito = (json) =>
{   
    if (json !== false)
    {
        datosCarrito.push(json)
    }

    else if (json == false && datosCarrito.length === 0)
    {
        document.getElementById("contenido").innerHTML = '<h2>El carrito está vacío.</h2>'
        document.getElementById("procesar").innerHTML = ''
    }

    else
    {
        let tabla = `
                <table>
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Título</th>
                            <th>Escritores</th>
                            <th>Género</th>
                            <th>Páginas</th>
                            <th>Imagén</th>
                            <th>Unidades</th>
                        </tr>
                    </thead>
                    <tbody>
                `
                for (let index = 0; index < datosCarrito.length; index++) 
                {
                    tabla +=`
                    <tr>
                        <td>${datosCarrito[index][1][0]}</td>
                        <td>${datosCarrito[index][2][0]}</td>
                        <td>${datosCarrito[index][3][0]}</td>
                        <td>${datosCarrito[index][4][0]}</td>
                        <td>${datosCarrito[index][5][0]}</td>
                        <td>
                            <img 
                                src="${datosCarrito[index][6][0]}" 
                                alt="Error loading image..."
                                with="25px" height="75px"
                            >
                        </td>
                        <td>${datosCarrito[index][7][0]}</td>
                        <td>
                            <input type="number" id="valor0">
                            <button type="button" onclick="eliminarLibros(${datosCarrito[index][1][0]})">Eliminar</button>
                        </td>
                    </tr>`
                }

        tabla.concat(`
                </tbody>
            </table>
        `)
        document.getElementById("titulo").innerHTML = 'Carrito de Libros'
        document.getElementById("contenido").innerHTML = tabla
        document.getElementById("procesar").innerHTML = 'Realizar pedido'
    }
}