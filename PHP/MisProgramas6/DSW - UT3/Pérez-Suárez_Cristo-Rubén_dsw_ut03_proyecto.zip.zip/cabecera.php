<header>

    Usuario: <?php echo $_SESSION['usuario']; ?>

    <br/><br/> Menú:

    <a href="#" onclick="cargarGeneros()"     >Listado de Generos</a> /
    <a href="#" onclick="cargarLibros()"      >Listado de Libros </a> /
    <a href="#" onclick="cargarCarrito(false)">Ver carrito       </a> /
    <a href="./logout.php" onclick="logout()" >Cerrar sesión     </a>

</header>

<hr>